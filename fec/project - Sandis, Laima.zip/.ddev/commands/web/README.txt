#ddev-generated
Scripts in this directory will be executed inside the web container.

See https://ddev.readthedocs.io/en/stable/users/extend/custom-commands/#environment-variables-provided for a list of environment variables that can be used in the scripts.
