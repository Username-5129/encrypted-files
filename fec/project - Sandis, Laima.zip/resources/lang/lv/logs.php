<?php
return [
    'activity_logs' => 'Activity Logs lv',
];