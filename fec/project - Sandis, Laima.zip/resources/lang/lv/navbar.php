<?php
return [
    'files' => 'Faili',
];
