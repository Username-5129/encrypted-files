<nav class="bg-gradient-to-b from-black/90 to-[#122C4F]/90 backdrop-blur border-b border-[#5B88B2]/30 shadow-lg sticky top-0 z-50">
  <div class="w-full px-8 sm:px-16">
    <div class="flex justify-between h-20 items-center">
      <div class="flex items-center">
        <a href="<?php echo e(route('home')); ?>">
          <img src="/fec-logo-2.png" alt="Logo" class="h-12 w-auto">
        </a>
        <div class="flex items-center space-x-10 ml-20">
          <a href="<?php echo e(route('files.index')); ?>" class="text-white font-semibold text-xl relative after:block after:h-0.5 after:bg-[#5B88B2] after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:duration-300 after:origin-left"><?php echo e(__('navbar.files')); ?></a>
          <?php if(auth()->guard()->check()): ?>
          <a href="<?php echo e(route('friends.index')); ?>" class="text-white font-semibold text-xl relative after:block after:h-0.5 after:bg-[#5B88B2] after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:duration-300 after:origin-left">Friends</a>
          <?php endif; ?>
        </div>
      </div>
      <div class="flex items-center space-x-4">

        <div id="clock" class="text-white">Loading time</div>

        <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('register')); ?>" class="text-[#122C4F] font-semibold text-lg rounded-full px-6 py-3 border border-gray-200 transition-shadow hover:shadow-xl bg-[#FBF9E4] hover:bg-[#f3f1db]">Register</a>
        <a href="<?php echo e(route('login')); ?>" class="text-[#122C4F] font-semibold text-lg rounded-full px-6 py-3 border border-gray-200 transition-shadow hover:shadow-xl bg-[#FBF9E4] hover:bg-[#f3f1db]">Login</a>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="text-[#122C4F] font-semibold text-lg rounded-full px-6 py-3 border border-gray-200 transition-shadow hover:shadow-xl bg-[#FBF9E4] hover:bg-[#f3f1db]">
                Logout
            </button>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav><?php /**PATH /var/www/html/resources/views/components/navbar.blade.php ENDPATH**/ ?>