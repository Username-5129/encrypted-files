<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Create New file
     <?php $__env->endSlot(); ?>
    <div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#122C4F] via-[#1e3a5c] to-black py-12 px-4">
        <div class="max-w-2xl w-full bg-[#1e3a5c]/90 p-8 rounded-2xl shadow-2xl border border-[#5B88B2]">
             <?php $__env->slot('header', null, []); ?> 
                <h1 class="text-2xl font-bold text-[#FBF9E4]">Create New file</h1>
             <?php $__env->endSlot(); ?>

            <h1 class="mb-4 text-2xl font-bold text-[#FBF9E4] text-center">Create New file</h1>
            <?php if($errors->any()): ?>
            <div class="bg-red-500 text-white p-4 rounded mb-4">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('file.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-[#FBF9E4]">Filename</label>
                    <input type="text" placeholder="Leave this empty to save the original filename" name="filename" value="<?php echo e(old('filename')); ?>" class="mt-1 block w-full border-[#5B88B2] rounded-lg shadow-sm focus:ring-2 focus:ring-[#5B88B2] focus:outline-none p-2 bg-[#122C4F] text-[#FBF9E4] placeholder-[#FBF9E4]/60">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-[#FBF9E4]">Description</label>
                    <textarea name="description" class="mt-1 block w-full border-[#5B88B2] rounded-lg shadow-sm focus:ring-2 focus:ring-[#5B88B2] focus:outline-none p-2 bg-[#122C4F] text-[#FBF9E4] placeholder-[#FBF9E4]/60" rows="5"><?php echo e(old('description')); ?></textarea>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-[#FBF9E4]">Is public</label>
                    <select name="is_public" class="mt-1 block w-full border-[#5B88B2] rounded-lg shadow-sm focus:ring-2 focus:ring-[#5B88B2] focus:outline-none p-2 bg-[#122C4F] text-[#FBF9E4]">
                        <option value="0" <?php echo e(old('is_public', '0') == '0' ? 'selected' : ''); ?>>No</option>
                        <option value="1" <?php echo e(old('is_public') == '1' ? 'selected' : ''); ?>>Yes</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-[#FBF9E4]">Password</label>
                    <input type="password" name="password_hash" value="<?php echo e(old('password_hash')); ?>" class="mt-1 block w-full border-[#5B88B2] rounded-lg shadow-sm focus:ring-2 focus:ring-[#5B88B2] focus:outline-none p-2 bg-[#122C4F] text-[#FBF9E4] placeholder-[#FBF9E4]/60" required>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-[#FBF9E4]">Confirm password</label>
                    <input type="password" name="confirm_password_hash" value="<?php echo e(old('confirm_password_hash')); ?>" class="mt-1 block w-full border-[#5B88B2] rounded-lg shadow-sm focus:ring-2 focus:ring-[#5B88B2] focus:outline-none p-2 bg-[#122C4F] text-[#FBF9E4] placeholder-[#FBF9E4]/60" required>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-[#FBF9E4]" for="stored_path">Upload file</label>
                    <input class="block w-full text-sm text-[#FBF9E4] border-[#5B88B2] rounded-lg bg-[#122C4F] focus:ring-2 focus:ring-[#5B88B2] focus:outline-none p-2 file:bg-[#5B88B2] file:text-[#FBF9E4] file:rounded file:border-0" id="stored_path" name="stored_path" type="file">
                </div>

                <button type="submit" class="mt-4 w-full bg-[#5B88B2] text-[#FBF9E4] font-bold py-2 px-4 rounded-lg hover:bg-[#49709a] transition">Create file</button>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/encrypted_files/create.blade.php ENDPATH**/ ?>